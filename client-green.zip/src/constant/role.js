export const USER_ROLE = {
  SUPER_ADMIN: "super_admin",
  ADMIN: "admin",
  USER: "user",
  EMPLOYEE: "employee",
  GUEST: "guest",
};
